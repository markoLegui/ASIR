-- Pregunta 5
select nomvend, count(*) CantPiezasSub
from vendedor v, preciosum ps
where v.numvend = ps.numvend 
group by nomvend
order by nomvend