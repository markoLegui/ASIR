-- Pregunta 10
select nompieza, avg(preciounit) MediaPrecioUd, preciovent
from pieza p, preciosum ps
where p.numpieza = ps.numpieza
and preciovent > 300
group by nompieza, preciovent
having avg(preciounit) between 100 and 280
order by nompieza