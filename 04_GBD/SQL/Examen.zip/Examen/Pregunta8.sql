-- Pregunta 8 
select ps.numpieza, sum(preciounit - preciocompra) DifEuros
from linped l, preciosum ps
where l.numpieza = ps.numpieza
group by ps.numpieza
order by DifEuros desc