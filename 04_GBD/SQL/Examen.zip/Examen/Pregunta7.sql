-- Pregunta 7 
select distinct p.numvend, nomvend
from vendedor v, pedido p
where v.numvend = p.numvend
and numpedido >= 1 