-- Pregunta 6
select v.numvend, nomvend
from vendedor v, pedido pd, linped l
where v.numvend = pd.numvend
and pd.numpedido = l.numpedido
and numlinea > 3
group by v.numvend, nomvend