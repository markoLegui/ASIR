-- Pregunta 9
select nombrecomer
from vendedor v, linped l, pedido pd, pieza p
where v.numvend = pd.numvend
and l.numpieza = p.numpieza
and pd.numpedido = l.numpedido
and provincia = 'ALICANTE'
and nompieza like 'Monitor%'