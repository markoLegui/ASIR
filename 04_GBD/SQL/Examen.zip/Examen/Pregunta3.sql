-- Pregunta 3
select distinct numvend
from pieza p, linped l, preciosum ps
where p.numpieza = l.numpieza 
and l.numpieza = ps.numpieza
and preciovent between 50 and 100
and numpedido > 1