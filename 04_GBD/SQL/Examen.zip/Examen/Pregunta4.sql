-- Pregunta 4 
select distinct nompieza, p.numpieza
from pieza p, pedido pd, linped l
where pd.numpedido = l.numpedido
and p.numpieza = l.numpieza
and l.numpedido > 1
order by nompieza