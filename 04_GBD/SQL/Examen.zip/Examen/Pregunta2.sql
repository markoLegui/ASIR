-- Pregunta 2
select distinct v.numvend, nombrecomer
from vendedor v, pieza p, preciosum ps
where v.numvend = ps.numvend
and p.numpieza = ps.numpieza
and preciovent > preciounit
