-- Pregunta 1
select v.numvend, nomvend, count (*) CantPiezas
from vendedor v, preciosum ps
where ps.numvend = v.numvend
group by v.numvend, nomvend
order by nomvend